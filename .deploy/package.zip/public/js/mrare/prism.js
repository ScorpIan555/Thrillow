//
//
// prism.js
//
// Initialises the prism code highlighting plugin

/* global Prism */

Prism.highlightAll();
